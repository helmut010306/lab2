package lab2

fun main() {
    // Введите сумму для перевода
    print("Введите сумму для перевода: ")
    val amountInput = readLine()

    // Введите тип карты (Mastercard, Maestro, Visa, Мир, VK Pay)
    print("Введите тип карты (Mastercard, Maestro, Visa, Мир, VK Pay): ")
    val cardType = readLine()

    val amount = amountInput?.toDoubleOrNull()

    if (amount == null || amount <= 0) {
        println("Введите корректную сумму для перевода")
    } else if (cardType.isNullOrEmpty()) {
        println("Введите тип карты")
    } else {
        val commissionPercent: Double
        val minimumCommission: Double

        when (cardType.toLowerCase()) {
            "mastercard", "maestro" -> {
                commissionPercent = if ( amount <= 75000) 0.0 else 0.006
                minimumCommission = if ( amount <= 75000) 0.0 else 20.0
            }
            "visa", "мир" -> {
                commissionPercent = 0.0075
                minimumCommission = 35.0
            }
            "vk pay" -> {
                commissionPercent = 0.0
                minimumCommission = 0.0
            }
            else -> {
                commissionPercent = 0.006
                minimumCommission = 20.0
            }
        }

        val commission = amount * commissionPercent
        val totalCommission = if (commission < minimumCommission)
            minimumCommission
        else
            commission

        println("Сумма перевода: $amount Рублей")
        println("Комиссия за перевод: $totalCommission Рублей")
    }
}